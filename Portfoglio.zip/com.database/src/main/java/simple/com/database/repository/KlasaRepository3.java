package simple.com.database.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa3;

@Repository
public interface KlasaRepository3 extends JpaRepository<Klasa3, Integer> {

}
