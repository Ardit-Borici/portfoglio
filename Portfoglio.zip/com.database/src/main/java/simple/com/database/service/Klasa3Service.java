package simple.com.database.service;

import java.util.List;

import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa2;
import simple.com.database.entity.Klasa3;


public interface Klasa3Service {

	public List<Klasa3> findAll();
	public Klasa3 findById(int id);
	public void save(Klasa3 theKlasa3);
	public void deleteById(int id);
	
	
}
