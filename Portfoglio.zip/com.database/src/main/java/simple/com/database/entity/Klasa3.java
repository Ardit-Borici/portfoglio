package simple.com.database.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="klasathree")
public class Klasa3 {

	@Column(name="id")
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="first_name")
	private String fName;
	
	@Column(name="last_name")
	private String lName;
	
	@Column(name="father_name")
	private String father;
	
	@Column(name="mother_name")
	private String mother;
	
	public Klasa3()  {
		
	}

	public Klasa3(int id, String fName, String lName, String father, String mother) {
		this.id = id;
		this.fName = fName;
		this.lName = lName;
		this.father = father;
		this.mother = mother;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getFather() {
		return father;
	}

	public void setFather(String father) {
		this.father = father;
	}

	public String getMother() {
		return mother;
	}

	public void setMother(String mother) {
		this.mother = mother;
	}

	@Override
	public String toString() {
		return "Klasa3 [id=" + id + ", fName=" + fName + ", lName=" + lName + ", father=" + father + ", mother="
				+ mother + "]";
	}

	

	
	
}
