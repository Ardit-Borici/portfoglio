package simple.com.database.service;

import java.util.List;

import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa2;


public interface Klasa2Service {

	public List<Klasa2> findAll();
	public Klasa2 findById(int id);
	public void save(Klasa2 theKlasa2);
	public void deleteById(int id);
	
	
}
