package simple.com.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import simple.com.database.entity.Klasa2;
import simple.com.database.entity.Klasa4;
import simple.com.database.repository.KlasaRepository4;

@Service
public class Klasa4ServiceImpl implements Klasa4Service {

	public KlasaRepository4 klasaRepository4;
	
	@Autowired
	public Klasa4ServiceImpl (KlasaRepository4 theKlasaRepository4) {
		klasaRepository4 = theKlasaRepository4;
	}
	
	
	@Override
	public List<Klasa4> findAll() {
		return klasaRepository4.findAll();
	}


	@Override
	public Klasa4 findById(int id) {
    Optional<Klasa4> result = klasaRepository4.findById(id);
		
		Klasa4 theKlasa4 = null;
		
		if(result.isPresent()) {
			theKlasa4=result.get();
		}
		else {
			throw new RuntimeException("Not found");
		}
		return theKlasa4;
	}


	@Override
	public void save(Klasa4 theKlasa4) {
    klasaRepository4.save(theKlasa4);	
	}


	@Override
	public void deleteById(int id) {
    klasaRepository4.deleteById(id);	
	}

}
