package simple.com.database.service;

import java.util.List;

import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa2;


public interface KlasaService {

	public List<Klasa1> findAll();
	public Klasa1 findById(int id);
	public void save(Klasa1 theKlasa1);
	public void deleteById(int id);
	
	
}
