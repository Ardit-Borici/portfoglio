package simple.com.database.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa2;
import simple.com.database.service.Klasa2Service;
import simple.com.database.service.KlasaService;

@Controller	
@RequestMapping("/klasa2")
public class Klasa2Controller {
	
	private Klasa2Service klasa2Service;
	
	public Klasa2Controller(Klasa2Service theKlasa2Service) {
		klasa2Service = theKlasa2Service;
	}

	@GetMapping("/list")
	public String showKlasa1(Model theModel) {
		List<Klasa2> theKlasa2 = klasa2Service.findAll();
		theModel.addAttribute("students", theKlasa2);
		return "klasa2/klasa-2";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Klasa2 theKlasa2 = new Klasa2();
		theModel.addAttribute("students",theKlasa2);
		return "klasa2/add-form";
	}
	
	@PostMapping("/save")
	public String saveKlasa2(@ModelAttribute("students") Klasa2 theKlasa2) {
			klasa2Service.save(theKlasa2);
			return "redirect:/klasa2/list";
		}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value="id") int id, Model theModel) {
		Klasa2 theKlasa2 = klasa2Service.findById(id);
		theModel.addAttribute("students", theKlasa2);
		return "klasa2/update-form";
	}
		
	@GetMapping("/delete/{id}")
	public String deleteKlasa2(@PathVariable(value="id") int id, Model theModel) {
		klasa2Service.findById(id);
			klasa2Service.deleteById(id);
			return "redirect:/klasa2/list";
		}
	}

