package simple.com.database.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa3;
import simple.com.database.service.Klasa3Service;

@Controller	
@RequestMapping("/klasa3")
public class Klasa3Controller {
	
	private Klasa3Service klasa3Service;
	
	public Klasa3Controller(Klasa3Service theKlasa3Service) {
		klasa3Service = theKlasa3Service;
	}

	@GetMapping("/list")
	public String showKlasa1(Model theModel) {
		List<Klasa3> theKlasa3 = klasa3Service.findAll();
		theModel.addAttribute("students", theKlasa3);
		return "klasa3/klasa-3";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Klasa3 theKlasa3 = new Klasa3();
		theModel.addAttribute("students",theKlasa3);
		return "klasa3/add-form";
	}
	
	@PostMapping("/save")
	public String saveKlasa3(@ModelAttribute("students") Klasa3 theKlasa3) {
			klasa3Service.save(theKlasa3);
			return "redirect:/klasa3/list";
		}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value="id") int id, Model theModel) {
		Klasa3 theKlasa3 = klasa3Service.findById(id);
		theModel.addAttribute("students", theKlasa3);
		return "klasa3/update-form";
	}
		
	@GetMapping("/delete/{id}")
	public String deleteKlasa3(@PathVariable(value="id") int id, Model theModel) {
		klasa3Service.findById(id);
			klasa3Service.deleteById(id);
			return "redirect:/klasa3/list";
		}
	}

