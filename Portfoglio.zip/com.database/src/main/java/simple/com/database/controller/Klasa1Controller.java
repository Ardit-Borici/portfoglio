package simple.com.database.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import simple.com.database.entity.Klasa1;
import simple.com.database.service.KlasaService;

@Controller	
@RequestMapping("/klasa1")
public class Klasa1Controller {
	
	private KlasaService klasaService;
	
	public Klasa1Controller(KlasaService theKlasaService) {
		klasaService = theKlasaService;
	}

	@GetMapping("/list")
	public String showKlasa1(Model theModel) {
		List<Klasa1> theKlasa1 = klasaService.findAll();
		theModel.addAttribute("students", theKlasa1);
		return "klasa1/klasa-1";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Klasa1 theKlasa1 = new Klasa1();
		theModel.addAttribute("students",theKlasa1);
		return "klasa1/add-form";
	}
	
	@PostMapping("/save")
	public String saveKlasa1(@ModelAttribute("students") Klasa1 theKlasa1) {
			klasaService.save(theKlasa1);
			return "redirect:/klasa1/list";
		}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value="id") int id, Model theModel) {
		Klasa1 theKlasa1 = klasaService.findById(id);
		theModel.addAttribute("students", theKlasa1);
		return "klasa1/update-form";
	}
		
	@GetMapping("/delete/{id}")
	public String deleteKlasa1(@PathVariable(value="id") int id, Model theModel) {
		klasaService.findById(id);
			klasaService.deleteById(id);
			return "redirect:/klasa1/list";
		}
	}

