package simple.com.database.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa4;
import simple.com.database.service.Klasa4Service;

@Controller	
@RequestMapping("/klasa4")
public class Klasa4Controller {
	
	private Klasa4Service klasa4Service;
	
	public Klasa4Controller(Klasa4Service theKlasa4Service) {
		klasa4Service = theKlasa4Service;
	}

	@GetMapping("/list")
	public String showKlasa1(Model theModel) {
		List<Klasa4> theKlasa4 = klasa4Service.findAll();
		theModel.addAttribute("students", theKlasa4);
		return "klasa4/klasa-4";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Klasa4 theKlasa4 = new Klasa4();
		theModel.addAttribute("students",theKlasa4);
		return "klasa4/add-form";
	}
	
	@PostMapping("/save")
	public String saveKlasa4(@ModelAttribute("students") Klasa4 theKlasa4) {
			klasa4Service.save(theKlasa4);
			return "redirect:/klasa4/list";
		}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value="id") int id, Model theModel) {
		Klasa4 theKlasa4 = klasa4Service.findById(id);
		theModel.addAttribute("students", theKlasa4);
		return "klasa4/update-form";
	}
		
	@GetMapping("/delete/{id}")
	public String deleteKlasa4(@PathVariable(value="id") int id, Model theModel) {
		klasa4Service.findById(id);
			klasa4Service.deleteById(id);
			return "redirect:/klasa4/list";
		}
	}

