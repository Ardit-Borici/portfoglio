package simple.com.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import simple.com.database.entity.Klasa1;
import simple.com.database.repository.KlasaRepository;

@Service
public class KlasaServiceImpl implements KlasaService {

	public KlasaRepository klasaRepository;
	
	@Autowired
	public KlasaServiceImpl (KlasaRepository theKlasaRepository) {
		klasaRepository = theKlasaRepository;
	}
	
	
	@Override
	public List<Klasa1> findAll() {
		return klasaRepository.findAll();
	}


	@Override
	public Klasa1 findById(int id) {
    Optional<Klasa1> result = klasaRepository.findById(id);
		
		Klasa1 theKlasa1 = null;
		
		if(result.isPresent()) {
			theKlasa1=result.get();
		}
		else {
			throw new RuntimeException("Not found");
		}
		return theKlasa1;
	}


	@Override
	public void save(Klasa1 theKlasa1) {
    klasaRepository.save(theKlasa1);	
	}


	@Override
	public void deleteById(int id) {
    klasaRepository.deleteById(id);	
	}

}
