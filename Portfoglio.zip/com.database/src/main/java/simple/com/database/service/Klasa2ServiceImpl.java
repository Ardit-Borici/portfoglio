package simple.com.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa2;
import simple.com.database.repository.KlasaRepository;
import simple.com.database.repository.KlasaRepository2;

@Service
public class Klasa2ServiceImpl implements Klasa2Service {

	public KlasaRepository2 klasaRepository2;
	
	@Autowired
	public Klasa2ServiceImpl (KlasaRepository2 theKlasaRepository2) {
		klasaRepository2 = theKlasaRepository2;
	}
	
	
	@Override
	public List<Klasa2> findAll() {
		return klasaRepository2.findAll();
	}


	@Override
	public Klasa2 findById(int id) {
    Optional<Klasa2> result = klasaRepository2.findById(id);
		
		Klasa2 theKlasa2 = null;
		
		if(result.isPresent()) {
			theKlasa2=result.get();
		}
		else {
			throw new RuntimeException("Not found");
		}
		return theKlasa2;
	}


	@Override
	public void save(Klasa2 theKlasa2) {
    klasaRepository2.save(theKlasa2);	
	}


	@Override
	public void deleteById(int id) {
    klasaRepository2.deleteById(id);	
	}

}
