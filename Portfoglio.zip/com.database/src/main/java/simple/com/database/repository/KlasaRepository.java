package simple.com.database.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import simple.com.database.entity.Klasa1;

@Repository
public interface KlasaRepository extends JpaRepository<Klasa1, Integer> {

}
