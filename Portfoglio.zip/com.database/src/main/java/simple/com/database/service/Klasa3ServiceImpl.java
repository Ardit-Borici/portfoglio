package simple.com.database.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa2;
import simple.com.database.entity.Klasa3;
import simple.com.database.repository.KlasaRepository;
import simple.com.database.repository.KlasaRepository2;
import simple.com.database.repository.KlasaRepository3;

@Service
public class Klasa3ServiceImpl implements Klasa3Service {

	public KlasaRepository3 klasaRepository3;
	
	@Autowired
	public Klasa3ServiceImpl (KlasaRepository3 theKlasaRepository3) {
		klasaRepository3 = theKlasaRepository3;
	}
	
	
	@Override
	public List<Klasa3> findAll() {
		return klasaRepository3.findAll();
	}


	@Override
	public Klasa3 findById(int id) {
    Optional<Klasa3> result = klasaRepository3.findById(id);
		
		Klasa3 theKlasa3 = null;
		
		if(result.isPresent()) {
			theKlasa3=result.get();
		}
		else {
			throw new RuntimeException("Not found");
		}
		return theKlasa3;
	}


	@Override
	public void save(Klasa3 theKlasa3) {
    klasaRepository3.save(theKlasa3);	
	}


	@Override
	public void deleteById(int id) {
    klasaRepository3.deleteById(id);	
	}

}
