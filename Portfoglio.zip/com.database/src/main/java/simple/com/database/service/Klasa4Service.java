package simple.com.database.service;

import java.util.List;

import simple.com.database.entity.Klasa4;


public interface Klasa4Service {

	public List<Klasa4> findAll();
	public Klasa4 findById(int id);
	public void save(Klasa4 theKlasa4);
	public void deleteById(int id);
	
	
}
