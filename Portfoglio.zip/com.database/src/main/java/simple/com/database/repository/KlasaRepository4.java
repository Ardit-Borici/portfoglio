package simple.com.database.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import simple.com.database.entity.Klasa1;
import simple.com.database.entity.Klasa4;

@Repository
public interface KlasaRepository4 extends JpaRepository<Klasa4, Integer> {

}
